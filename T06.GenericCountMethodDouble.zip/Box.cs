﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T06.GenericCountMethodDouble
{
    class Box<T> where T : IComparable<T>
    {
        public List<T> Collection { get; set; }

        public Box()
        {
            Collection = new List<T>();
        }

        public int Compare(T compare)
        {
            int count = 0;

            foreach (T item in Collection)
            {
                if (item.CompareTo(compare) > 0)
                {
                    count++;
                }
            }

            return count;
        }

    }
}
