﻿using System;

namespace T08.Tuple
{
    public class Program
    {
        static void Main(string[] args)
        {

            string[] person = Console.ReadLine().Split();

            MyTuple<string, string> personization = new MyTuple<string, string>($"{person[0]}" + $" {person[1]}", person[2]);

            string[] drinking = Console.ReadLine().Split();

            MyTuple<string, int> beer = new MyTuple<string, int>(drinking[0], int.Parse(drinking[1]));

            string[] info = Console.ReadLine().Split();

            MyTuple<int, double> infor = new MyTuple<int, double>(int.Parse(info[0]), double.Parse(info[1]));

            Console.WriteLine(personization);
            Console.WriteLine(beer);
            Console.WriteLine(infor);
        }
    }
}
