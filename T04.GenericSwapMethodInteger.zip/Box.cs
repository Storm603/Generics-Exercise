﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T04.GenericSwapMethodInteger
{
    public class Box<T>
    {
        public List<T> Collection { get; set; }

        public Box()
        {
            Collection = new List<T>();
        }

        public void Swap(int index1, int index2)
        {
            T temp = Collection[index1];
            Collection[index1] = Collection[index2];
            Collection[index2] = temp;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            foreach (T item in Collection)
            {
                sb.AppendLine($"{typeof(T)}: {item}");
            }

            return sb.ToString();
        }
    }
}
