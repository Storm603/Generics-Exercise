﻿using System;

namespace T01._Generic_Box_of_Strings
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            Box<string> box = new Box<string>();

            for (int i = 0; i < n; i++)
            {
                string input = Console.ReadLine();

                box.collection.Add(input);
            }

            Console.WriteLine(box);
        }
    }
}
