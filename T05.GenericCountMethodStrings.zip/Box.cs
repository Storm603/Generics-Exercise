﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace T05.GenericCountMethodStrings
{
    public class Box<T> where T : IComparable<T>
    {
        public List<T> Collection { get; set; }

        public Box()
        {
            Collection = new List<T>();
        }

        //public void Swap(int index1, int index2)
        //{
        //    T temp = Collection[index1];
        //    Collection[index1] = Collection[index2];
        //    Collection[index2] = temp;
        //}

        public int Compare(T compare)
        {
            int count = 0;

            foreach (T item in Collection)
            {
                if (item.CompareTo(compare) > 0)
                {
                    count++;
                }
            }

            return count;
        }

        //public override string ToString()
        //{
        //    StringBuilder sb = new StringBuilder();

        //    foreach (T item in Collection)
        //    {
        //        sb.AppendLine($"{typeof(T)}: {item}");
        //    }

        //    return sb.ToString();
        //}
    }
}