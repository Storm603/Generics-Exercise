﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T08.Threeuple
{
    public class MyTuple<T1,T2, T3>
    {
        public T1 Item1 { get; set; }
        public T2 Item2 { get; set; }
        public T3 Item3 { get; set; }

        public MyTuple(T1 i1, T2 i2, T3 i3)
        {
            Item1 = i1;
            Item2 = i2;
            Item3 = i3;
        }

        public override string ToString()
        {
            return $"{Item1} -> {Item2} -> {Item3}";
        }
    }
}
