﻿using System;

namespace T08.Threeuple
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] person = Console.ReadLine().Split();

            MyTuple<string, string, string> personization = new MyTuple<string, string, string>($"{person[0]}" + $" {person[1]}", person[2], person[3]);

            string[] drinking = Console.ReadLine().Split();

            bool isDrunk = drinking[2] == "drunk";

            MyTuple<string, int, bool> beer = new MyTuple<string, int, bool>(drinking[0], int.Parse(drinking[1]), isDrunk);

            string[] info = Console.ReadLine().Split();

            MyTuple<string, double, string> infor = new MyTuple<string, double, string>(info[0], double.Parse(info[1]), info[2]);

            Console.WriteLine(personization);
            Console.WriteLine(beer);
            Console.WriteLine(infor);
        }
    }
}
