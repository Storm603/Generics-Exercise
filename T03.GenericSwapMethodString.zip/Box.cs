﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T03.GenericSwapMethodString
{
    public class Box<T>
    {
        public List<T> collection { get; set; }

        public Box()
        {
            collection = new List<T>();
        }

        public void Swap(int index1, int index2)
        {
            T temp = collection[index1];
            collection[index1] = collection[index2];
            collection[index2] = temp;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            foreach (T item in collection)
            {
                sb.AppendLine($"{typeof(T)}: {item}");
            }

            return sb.ToString();
        }
    }
}
