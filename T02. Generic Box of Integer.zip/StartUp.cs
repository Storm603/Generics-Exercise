﻿using System;

namespace T02._Generic_Box_of_Integer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());

            Box<int> box = new Box<int>();

            for (int i = 0; i < n; i++)
            {
                int input = int.Parse(Console.ReadLine());

                box.collectionInt.Add(input);
            }

            Console.WriteLine(box);
        }
    }
}
