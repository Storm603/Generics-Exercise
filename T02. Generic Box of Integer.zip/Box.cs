﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T02._Generic_Box_of_Integer
{
    public class Box<T>
    {
        public List<T> collectionInt { get; set; }

        public Box()
        {
            collectionInt = new List<T>();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            foreach (T item in collectionInt)
            {
                sb.AppendLine($"{typeof(T)}: {item}");
            }

            return sb.ToString();
        }
    }
}
